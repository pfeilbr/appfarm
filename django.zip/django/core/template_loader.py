# This module is DEPRECATED!
#
# You should no longer be using django.template_loader.
#
# Use django.template.loader instead.

from django.template.loader import *
